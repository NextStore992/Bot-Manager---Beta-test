# Nexus Manager

O painel visual definitivo para gestão de bots no Discord!

Controle, monitore e administre múltiplos bots em diversas engines (Discloud, Docker, Local, etc.) através de uma interface interativa, responsiva e segura, direto no Discord.

**Desenvolvido por @079byfael | Frost Applications | UDO - Ultimate Developer Owner**

> [BETA] — Painel em desenvolvimento, feedbacks são bem-vindos!

## Principais recursos

- Dashboard interativo via Slash Commands
- Visualização e controle de bots (start, stop, restart, logs, stats)
- Configuração por menus
- Auditoria e logs
- Permissões avançadas
- Compatível com Replit Secrets

---

**GitHub:** https://github.com/NextStore992/Bot-Manager---Beta-test